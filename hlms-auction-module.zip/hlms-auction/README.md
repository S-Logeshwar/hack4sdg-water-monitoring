# HDFC Bank — Auction Module UI

Static HTML/CSS/JS prototype for the Auction module, styled to match the
HLMS (Housing Loan Management System) look — light canvas, navy sidebar,
single green system accent, card-based layout.

## How to run
Just open `index.html` (or `dashboard.html`) directly in a browser.
No build step or server required. An internet connection is needed to
load Google Fonts and Font Awesome icons from their CDNs.

## Pages
| File | Screen |
|---|---|
| `dashboard.html` | Auction Dashboard (Home) |
| `auctions.html` | Auction Listings |
| `property-details.html` | Property Details |
| `registration.html` | 4-step Registration (Personal → KYC → Bank → Review) |
| `emd-payment.html` | EMD Payment (UPI / Card / Net Banking / QR) |
| `payment-success.html` | Payment Success + auction credentials |
| `auction-schedule.html` | Auction Schedule with live countdown |
| `auction-login.html` | Auction Login (Auction ID / Password / OTP) |
| `live-auction.html` | Live Auction room with real-time bidding + leaderboard |
| `auction-result.html` | Auction Result (winner) |
| `my-bids.html` | My Bids (supporting page, linked from sidebar) |
| `profile.html` | Profile (supporting page) |
| `support.html` | Support (supporting page) |

## Structure
```
hlms-auction/
├── index.html
├── dashboard.html ... auction-result.html
├── css/style.css      -> all design tokens & components
├── js/main.js          -> shared sidebar/topbar injection + countdowns
└── README.md
```

## Notes on interactivity
- **Registration**: step buttons advance/rewind a real stepper state machine.
- **EMD Payment**: clicking a payment method swaps the active state; "Verify & Pay" routes to the success screen.
- **Auction Login**: "Send OTP" reveals a confirmation hint; login routes to the live room.
- **Live Auction**: "Place Bid" increments the highest bid and pushes a row into Bid History; a background timer occasionally simulates a rival bid so the leaderboard feels live.
- **Schedule**: countdown blocks tick down every second via `data-block-countdown` (seconds until auction start).

Colors, spacing and type scale are all defined as CSS variables at the top of
`css/style.css` — change them there to re-theme every page at once.
